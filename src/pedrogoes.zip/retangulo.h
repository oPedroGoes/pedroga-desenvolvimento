#ifndef RETANGULO_H
#define RETANGULO_H
    
    typedef void* RECTANGLE;


    RECTANGLE create_rectangle(int id, double x, double y, double w, double h, char* cb, char* cp);


    int get_idR(RECTANGLE r);
    void set_idR(RECTANGLE r, int id);

    double get_XR(RECTANGLE r);
    void set_xR(RECTANGLE r, double x);

    double get_YR(RECTANGLE r);
    void set_yR(RECTANGLE r, double y);

    char* get_cbR(RECTANGLE r);
    void set_cbR(RECTANGLE r, char* cb);

    char* get_cpR(RECTANGLE r);
    void set_cpR(RECTANGLE r, char* cp);

    /**
    * @brief Pega por meio de um TAD a largura da borda do retangulo.
    * @param r Estrutura do retangulo para pegar a informação.
    * @return Retorna um double com a largura da borda.
    */
    double get_strkWR(RECTANGLE r);

    /**
    * @brief Muda a largura da borda do retangulo.
    * @param r Estrutura do retangulo que vai ter a largura da borda mudada.
    * @param sw Nova largura da borda.
    */
    void set_strkWR(RECTANGLE r, double sw);

    double get_wR(RECTANGLE r);

    double get_hR(RECTANGLE r);

    double get_areaR(RECTANGLE r);

    void kill_rectangle(RECTANGLE r);


#endif